﻿#include "MecanumCar_v4.h"
#include "Arduino.h"

mecanumCar::mecanumCar(int _sda, int _scl)
{
  SDA = _sda;
  SCL = _scl;
  pinMode(SDA, OUTPUT); //SDA总线为输出模式
  pinMode(SCL, OUTPUT); //SCL总线为输出模式
}

/* mecanumCar初始化函数
 */
void mecanumCar::Init() {
  delay(1000);
  right_led(0);
  left_led(0);
  Stop();
}

void mecanumCar::Stop() {
  Motor_Upper_L(0, 0);
  Motor_Lower_L(0, 0);
  Motor_Upper_R(0, 0);
  Motor_Lower_R(0, 0);
}

void mecanumCar::Advance(int lu, int ll, int ru, int rl)
{
  Motor_Upper_L(1, lu);
  Motor_Lower_L(1, ll);
  Motor_Upper_R(1, ru);
  Motor_Lower_R(1, rl);
}

void mecanumCar::Back(int lu, int ll, int ru, int rl)
{
  Motor_Upper_L(0, lu);
  Motor_Lower_L(0, ll);
  Motor_Upper_R(0, ru);
  Motor_Lower_R(0, rl);
}

void mecanumCar::Turn_Left(int lu, int ll, int ru, int rl)
{
  Motor_Upper_L(0, lu);
  Motor_Lower_L(0, ll);
  Motor_Upper_R(1, ru);
  Motor_Lower_R(1, rl);
}

void mecanumCar::Turn_Right(int lu, int ll, int ru, int rl)
{
  Motor_Upper_L(1, lu);
  Motor_Lower_L(1, ll);
  Motor_Upper_R(0, ru);
  Motor_Lower_R(0, rl);
}

void mecanumCar::L_Move(int lu, int ll, int ru, int rl)
{
  Motor_Upper_L(0, lu);
  Motor_Lower_L(1, ll);
  Motor_Upper_R(1, ru);
  Motor_Lower_R(0, rl);
}

void mecanumCar::R_Move(int lu, int ll, int ru, int rl)
{
  Motor_Upper_L(1, lu);
  Motor_Lower_L(0, ll);
  Motor_Upper_R(0, ru);
  Motor_Lower_R(1, rl);
}

void mecanumCar::LU_Move()
{
  Motor_Upper_L(0, 0);
  Motor_Lower_L(1, 80);
  Motor_Upper_R(1, 80);
  Motor_Lower_R(0, 0);
}

void mecanumCar::LD_Move()
{
  Motor_Upper_L(0, 80);
  Motor_Lower_L(0, 0);
  Motor_Upper_R(0, 0);
  Motor_Lower_R(0, 80);
}

void mecanumCar::RU_Move()
{
  Motor_Upper_L(1, 80);
  Motor_Lower_L(0, 0);
  Motor_Upper_R(0, 0);
  Motor_Lower_R(1, 80);
}

void mecanumCar::RD_Move()
{
  Motor_Upper_L(0, 0);
  Motor_Lower_L(0, 80);
  Motor_Upper_R(0, 80);
  Motor_Lower_R(0, 0);
}

void mecanumCar::drift_left()
{
  Motor_Upper_L(0, 0);
  Motor_Lower_L(0, 80);
  Motor_Upper_R(0, 0);
  Motor_Lower_R(1, 80);
}

void mecanumCar::drift_right()
{
  Motor_Upper_L(0, 0);
  Motor_Lower_L(1, 80);
  Motor_Upper_R(0, 0);
  Motor_Lower_R(0, 80);
}

void mecanumCar::Motor_Upper_L(bool stateL, int left1)
{
  if (stateL) {
    PWM_OUT(3, 0);
    PWM_OUT(4, left1);
  } else {
    PWM_OUT(3, left1);
    PWM_OUT(4, 0);
  }
}

void mecanumCar::Motor_Lower_L(bool stateL, int left1)
{
  if (stateL) {
    PWM_OUT(7, 0);
    PWM_OUT(8, left1);
  } else {
    PWM_OUT(7, left1);
    PWM_OUT(8, 0);
  }
}

void mecanumCar::Motor_Upper_R(bool stateR, int right1)
{
  if (stateR) {
    PWM_OUT(1, 0);
    PWM_OUT(2, right1);
  } else {
    PWM_OUT(1, right1);
    PWM_OUT(2, 0);
  }
}

void mecanumCar::Motor_Lower_R(bool stateR, int right1)
{
  if (stateR) {
    PWM_OUT(5, 0);
    PWM_OUT(6, right1);
  } else {
    PWM_OUT(5, right1);
    PWM_OUT(6, 0);
  }
}

void mecanumCar::right_led(bool onoff)
{
  digitalWrite_P55(onoff);
}

void mecanumCar::left_led(bool onoff)
{
  digitalWrite_P54(onoff);
}

void mecanumCar::digitalWrite_P55(bool val)
{
  Writebyte(0x0A, val);
}

void mecanumCar::digitalWrite_P54(bool val)
{
  Writebyte(0x09, val);
}

void mecanumCar::PWM_OUT(uint8_t ch, uint8_t pwm) 
{
  Writebyte(ch, pwm);
}

void mecanumCar::Writebyte(uint8_t addr, uint8_t dat) 
{
  IIC_Start();
  IIC_SendByte(0x30<<1);
  IIC_RecvACK();
  IIC_SendByte(addr);
  IIC_RecvACK();
  IIC_SendByte(dat);
  IIC_RecvACK();
  IIC_Stop();
}

void mecanumCar::IIC_Start() {
  digitalWrite(SDA, HIGH);
  delayMicroseconds(1);
  digitalWrite(SCL, HIGH); //拉高时钟线
  delayMicroseconds(1);  //延时2us
  digitalWrite(SDA, LOW);
  delayMicroseconds(1);
  digitalWrite(SCL, LOW);
  delayMicroseconds(1);
}

void mecanumCar::IIC_Stop() {
  digitalWrite(SCL, LOW);  //拉低数据线
  delayMicroseconds(1);
  digitalWrite(SDA, LOW);  //拉低时钟线
  delayMicroseconds(1);    //延时us
  digitalWrite(SCL, HIGH);
  delayMicroseconds(1);
  digitalWrite(SDA, HIGH);
  delayMicroseconds(1);
}

void mecanumCar::IIC_SendACK(bool ack) {
  digitalWrite(SDA, ack);   //写应答信号
  delayMicroseconds(1);
  digitalWrite(SCL, HIGH);  //拉高时钟线，等待读取应答信号
  delayMicroseconds(1);  //延时
  digitalWrite(SCL, LOW);   //拉低时钟线
  delayMicroseconds(1);   //延时
}

bool mecanumCar::IIC_RecvACK() {
  bool CY;
  digitalWrite(SCL, LOW);
  //digitalWrite(SDA, HIGH); //释放总线，<这里不拉高波形更好。。。>
  pinMode(SDA, INPUT);  //这里要读取信号，所以数据线设置为INPUT
  digitalWrite(SCL, HIGH);
  delayMicroseconds(1);
  CY = digitalRead(SDA);
  digitalWrite(SCL, LOW);
  pinMode(SDA, OUTPUT);//必须要重新设置输出模式
  return CY;
}

void mecanumCar::IIC_SendByte(unsigned char dat) { //dat是要发送的一个字节的数据
  uint8_t i;
  for (i = 0; i < 8; i++) {  //高位开始传输
    digitalWrite(SCL, LOW);
    delayMicroseconds(1);
    if (0x80 & dat) digitalWrite(SDA, HIGH);  //置1
    else digitalWrite(SDA, LOW);  //置0
    dat <<= 1;
    delayMicroseconds(1);  //延时
    digitalWrite(SCL, HIGH);  //拉高时钟线 读取数据
    delayMicroseconds(1);
  }
}

unsigned char mecanumCar::IIC_RecvByte() {
  digitalWrite(SDA, HIGH); //释放总线
  uint8_t i;
  uint8_t dat = 0;    //dat是存放接收到的一个字节的数据
  pinMode(SDA, INPUT);  //这里要读取信号，所以数据线设置为INPUT
  for (i = 0; i < 8; i++) {
    digitalWrite(SCL, HIGH);
    delayMicroseconds(1);
    dat <<= 1;
    if (digitalRead(SDA)) dat++;
    delayMicroseconds(1);
    digitalWrite(SCL, LOW);
    delayMicroseconds(1);
  }
  pinMode(SDA, OUTPUT);
  return dat;
}